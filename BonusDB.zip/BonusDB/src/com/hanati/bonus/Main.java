package com.hanati.bonus;

import com.hanati.bonus.presentation.MainController;

public class Main {

	public static void main(String[] args) {
		MainController mainController = new MainController();
	}

}
